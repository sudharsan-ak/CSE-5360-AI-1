In the file puzzle_facts1.txt puzzle_fact2.txt and puzzle_facts3.txt, the tiles are defined
and the locations are defined. The initial state are defined in the preconds,
along with the additional instances that verify that the correct tile is passed
and the location passed is also valid. The tileAt instance tells that which tile
is at the specified location.


In the file puzzle_ops.txt, we applied four functions that are moveleft, moveright,
moveup and movedown. assuming the grid to be in a straight line, and for left,
right, incrementing and decrementing according to the empty space, and for up, down 
incrementing and decrementing by a factor of 3 according to the empty space.