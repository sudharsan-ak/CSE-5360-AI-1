import java.io.*;

public class task5 {

        public static void main(String[] args)throws Exception {
                
                File mFile = new File("training_data.txt");
                
                double totalRcd = 0, trueBb = 0, trueTV = 0, trueNf = 0,
                                trueTnN = 0, yesTnoN = 0, yesNnoT = 0, falseTnN = 0,
                                trueTGivenB = 0,trueFGivenTnN = 0,trueFGivenT = 0,trueFGivenN = 0,trueFnoTnN = 0,
                                p,q,r,s;
                
                        BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\AK\\Desktop\\training_data.txt"));
                       
                        String line;
                        
                        while((line = br.readLine()) != null)
                        {
                                line = line.replaceAll("\\s","");

                              totalRcd++;
                               
                              p = Character.getNumericValue(line.charAt(0)) * 1.0;
                               
                              if(p == 1)
                                       trueBb++;
                               
                              	q = Character.getNumericValue(line.charAt(1)) * 1.0;
                               
                              	if(q == 1){
                                        	trueTV++;
                                        
                                       if(p == 1)
                                                trueTGivenB++;
                                }
                               
                              	r = Character.getNumericValue(line.charAt(2)) * 1.0;
                              		if(r == 1)
                                        trueNf++;
                              		s = Character.getNumericValue(line.charAt(3)) * 1.0;
                               
                              		if((q == 1) && (r == 1))
                                        trueTnN++;
                                
                              		else if(q == 1)
                                        yesTnoN++;
                                
                              		else if(r == 1)
                                        yesNnoT++;
                                
                              		else
                                        falseTnN++;
                                if(s == 1){
                                        
                                	if((q == 1) && (r == 1))
                                                trueFGivenTnN++;
                                       
                                	else if(q == 1)
                                                trueFGivenT++;
                                       
                                	else if(r == 1)
                                                trueFGivenN++;
                                       
                                	else
                                                trueFnoTnN++;
                                }
                        }
                        
                  
                System.out.println("\n P(B) = "+(trueBb/totalRcd));
                System.out.println("\n P(TV|B) for B = true  = "+(trueTGivenB/trueBb));
                System.out.println("\n P(TV|B) for B = false = "+((trueTV - trueTGivenB)/(totalRcd-trueBb)));
                System.out.println("\n P(N) = "+(trueNf/totalRcd));
                System.out.println("\n P(F|TV,N) for TV = true & N = true       = "+(trueFGivenTnN/trueTnN));
                System.out.println("\n P(F|TV,N) for TV = true & N = false      = "+(trueFGivenT/yesTnoN));
                System.out.println("\n P(F|TV,N) for TV = false & N = true      = "+(trueFGivenN/yesNnoT));
                System.out.println("\n P(F|TV,N) for TV = false & N = false     = "+(trueFnoTnN/falseTnN));
        }

}
