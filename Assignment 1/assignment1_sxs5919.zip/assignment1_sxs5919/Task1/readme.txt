Name : Sudharsan Srinivasan
UTA ID : 1001755919

Programming Language Used:
java version "1.8.0_20"
Java(TM) SE Runtime Environment (build 1.8.0_20-b26)
Java HotSpot(TM) 64-Bit Server VM (build 25.20-b23, mixed mode)

System Requirement:
1) This program is built and tested on Java 1.8. So, it is advisable that your computer should have Java(1.8) installed in your machine.

Execution Steps:
1) Unzip the folder assignment1_sxs5919.zip.
2) Navigate to the extracted folder assignment1_sxs5919/Task1.
3) Navigate in command line to that directory and you should see the below file:
      A) find_route.java B)readme.txt
4) Compile the java program with the below commands from command line:
      javac find_route.java
5) Then run the java program:
      java find_route <Path to input1.txt> <Source> <Destination> <Path to Heuristic file.txt>
      Ex: java find_route /path/to/input1.txt Bremen Kassel 
          java find_route /path/to/input1.txt Bremen Kassel /path/to/h_kassel.txt
6) The number of arguments passed for informed and uninformed search varies. So if you pass the correct number of arguments, you should see the expected output in the console.
Otherwise, the program would instruct you to pass in the correct arguments to run.

Code Structure:
1) This program will need the below arguments to run:
     A) input file path
     B) Source City
     C) Destination City
     D) Heuristic file(optional)
2) Storing the data reading from input file in to an ArrayList of NodeInfo and same for heuristic file too.
3) Add the source city to the fringe with parent as null
4) expandNodes() method is invoked & the value in the 0th position in the fringe is popped
5) Children of popped node are added to the fringe and popped node will be removed from the fringe and added to ciyVisitedList
6) The fringe will be sorted 
    (Uniform Cost Search)If its an uninformed search, the fringe will be sorted with the cumulative cost and 
    (Informed Search)If it is informed search then the fringe will be sorted by the cumulative cost + heuristic value
7) Again the least element is passed to the function to find its adjacent cities.
8) if the fringe is empty there is no path from origin city to destination city and the returned value is infinite 
9) If the current popped value from the fringe is the destination city, then the function would exit and backtrack() method is invoked
10) backtrack() method is used to find optimal path by backtracking the cityVisitedList 
11)nodesGenerated gives the number of nodes generated (nodes added to the fringe)
12)nodesExpanded gives the number of nodes expanded (length of visited nodes)
13)maxNodesInFringe gives the max number of nodes stored in memory

Note: If you are having trouble running the above command, you should either need to set JAVA_HOME from the terminal or use the java from your JDK installation folder(Ex: /Library/Java/JavaVirtualMachines/jdk1.8.0_121.jdk/Contents/Home/bin).
City names are case-sensitive. Ex: ‘Bremen’ and ‘bremen’ would not be the same. You need to choose as is from the input text file.
