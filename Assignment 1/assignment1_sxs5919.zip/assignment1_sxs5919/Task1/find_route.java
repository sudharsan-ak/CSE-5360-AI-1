import java.io.*;
import java.util.*;


public class find_route {

    public static BufferedReader buffer;
    public static BufferedReader buffer2;

    public static final String fileEnd = "END OF INPUT";
    public static String destination;

    private static int cumulativeCost;

    public static HashMap<String, Integer> heuristicValue = new HashMap<String, Integer>();
    public static ArrayList<String> citiesVisited = new ArrayList<String>();
    public static ArrayList<NodeInfo> fringe = new ArrayList<NodeInfo>();
    public static ArrayList<NodeInfo> citiesInfosList = new ArrayList<NodeInfo>();
    public static ArrayList<NodeInfo> citiesVisitedList = new ArrayList<NodeInfo>();

    public static int nodesGenerated;
    public static int nodesExpanded;
    public static int maxNodesInFringe = 1;

    public static FileReader firstFile;
    public static FileReader secondFile;

    public static File filePath;
    public static File heurisFile;

    private static boolean unInformed = true;

    /**
     * main function which differentiates between uninformed and informed search and calls
     * there respective functions.
     *
     * @param args
     * @throws Exception 
     */ 
    public static void main(String[] args) {
        try {
            String path = null;
            String source = null;
            String heuristicFileArg = null;
            /**
             * Reads the arguments from command line and validate them
             */
            if(args.length == 3) {
                path = args[0];
                source = args[1];
                destination = args[2];
            	System.out.println("#########################################################");
                System.out.println("\tUNINFORMED SEARCH (Uniform Cost Search)");
            	System.out.println("#########################################################");
            } else if(args.length == 4) {
                path = args[0];
                source = args[1];
                destination = args[2];
                heuristicFileArg = args[3]; 
                unInformed = false;
            	System.out.println("#########################################################");
                System.out.println("\t    INFORMED SEARCH (A* Search)");
            	System.out.println("#########################################################");
            }else {
            	System.out.println("This Program needs either 3 or 4 Parameters to run. Exiting..");
                System.out.println("1st Argument: Input text file");
                System.out.println("2nd Argument: Source City");
                System.out.println("3rd Argument: Destination City");
                System.out.println("4th Argument(optional): Heuristic file");
            	System.exit(0);
            }
         
            filePath = new File(path);
            firstFile = new FileReader(filePath);
            buffer = new BufferedReader(firstFile);
       
            storeCityInfo(buffer);

            fringe.add(new NodeInfo(null, source, 0));
            cumulativeCost = 0;
            
            /**
             * read and store heuristic file info for informed search
             */
            if (!unInformed) {
                heurisFile = new File(heuristicFileArg);
                secondFile = new FileReader(heurisFile);
                buffer2 = new BufferedReader(secondFile);
              
                storeHeuristicInfo(buffer2);
            }
            if (source.equals(destination)) {
                System.out.println("distance : 0 km \nroute \n" + source + " to " + destination + ", 0 km");
            } else {
                expandNodes(fringe.get(0));
            }
        } catch (Exception exception) {
            System.out.println("exception - " + exception.getMessage());
        }
    }
    
    /**
     * store the city file info
     * @param reader
     * @throws Exception 
     */ 
    public static void storeCityInfo(BufferedReader reader) throws Exception {
        String currentLineInFile;
        for (;!(currentLineInFile = buffer.readLine()).contains(fileEnd);) {
            String[] city = currentLineInFile.split(" ");
            citiesInfosList.add(new NodeInfo(city[0], city[1], Integer.parseInt(city[2])));
            citiesInfosList.add(new NodeInfo(city[1], city[0], Integer.parseInt(city[2])));
        }
    }
    
    /**
     * store the heuristic file info in arraylist
     * @param reader
     * @throws Exception 
     */
    public static void storeHeuristicInfo(BufferedReader reader) throws Exception {
        String currentLineInFile;

        /* Accessing every line and spliting it with space */
        for (;!(currentLineInFile = reader.readLine()).contains(fileEnd);) {
            String[] city = currentLineInFile.split(" ");
            heuristicValue.put(city[0], Integer.parseInt(city[1]));
        }
    }

    /**
     * this method performs (pop the least cost node from the fringe, add its child nodes
     * to the fringe and add expanded node to the visited list
     * @param city - city to be expanded
     * @throws Exception 
     */
    public static void expandNodes(NodeInfo city) throws Exception {
        cumulativeCost = city.totalCost;
        if (fringe.size() <= 0) {
            System.out.println("distance: infinity");
            System.out.println("route: \nnone");
        } else if (city.current.equals(destination)) {
            citiesVisitedList.add(city);
            backTrackPath(citiesVisitedList);
        } else if (fringe.size() > 0) {
            fringe.remove(city);
            nodesExpanded++;
            if (!citiesVisited.contains(city.current)) {
                maxNodesInFringe--;
            }

            for (NodeInfo currentCity : citiesInfosList) {
                if (currentCity.parent.equals(city.current)) {
                   
                    if (!citiesVisited.contains(city.current)) {
                        currentCity.totalCost = currentCity.cost + cumulativeCost;
                        fringe.add(currentCity);
                        /* Incrementing the maxNodesInFringe when we add nodes to the fringe */
                        maxNodesInFringe++;
                        nodesGenerated++;
                    }
                }
            }

            if (!citiesVisited.contains(city.current)) 
            {
                citiesVisitedList.add(city);
                citiesVisited.add(city.current);
            }
         
            if (fringe.size() > 0) {
                if (!unInformed) {
                    Collections.sort(getCumulativeCost(fringe), NodeInfo.totalCostComparator);
                    expandNodes(fringe.get(0));
                } else {
                    Collections.sort(fringe, NodeInfo.totalCostComparator);
                    expandNodes(fringe.get(0));
                }
            } else {
                backTrackPath(null);
                System.out.println("distance: infinity");
                System.out.println("route: \nnone");
            }
        }
    }
    
    /**
     * Node structure to store NodeInfo
     */
    static class NodeInfo {
        String current;
        String parent;
        int cost;
        int heuristicCost;
        int totalCost = 0;

        public NodeInfo(String parent, String name, int cost) {
            this.parent = parent;
            this.current = name;
            this.cost = cost;
        }

        // comparator to compare two objects;
        public static Comparator<NodeInfo> totalCostComparator = new Comparator<NodeInfo>() {
            public int compare(NodeInfo s1, NodeInfo s2) {
                return s1.totalCost - s2.totalCost;
            }
        };
    }

    /**
     * add the cumulative cost of node with its heuristic cost to perform A* search
     * @param list
     * @return
     * @throws Exception 
     */
    public static ArrayList<NodeInfo> getCumulativeCost(ArrayList<NodeInfo> list) throws Exception {
        int j;
        j = 0;

        while (j < list.size()) {
            list.get(j).heuristicCost = heuristicValue.get(list.get(j).current);
            list.get(j).totalCost = list.get(j).cost + list.get(j).heuristicCost;
            j++;
        }
        return list;
    }

    /**
     * Back track to compose the final optimal Path
     * Prints the nodes in the requested format
     */
    public static void backTrackPath(ArrayList<NodeInfo> finalList) {
         if (finalList != null) {
            nodesExpanded++;
        }
        System.out.println("");
        System.out.println("nodes expanded:" + (nodesExpanded));
        System.out.println("nodes generated:" + (nodesGenerated));
        System.out.println("max nodes in memory:" + maxNodesInFringe);
        
        if (finalList != null) {
            ArrayList<NodeInfo> connectedList = new ArrayList<NodeInfo>();
            connectedList.add(finalList.get(finalList.size() - 1));
            int totalCost = connectedList.get(0).cost;
            String parent = connectedList.get(0).parent;

            for (int i = finalList.size() - 2;i != 0;i--) {
                if (finalList.get(i).current.equals(parent)) {
                    parent = finalList.get(i).parent;
                    totalCost += finalList.get(i).cost;
                    connectedList.add(finalList.get(i));
                }
            }

            System.out.println("distance: " + (float) totalCost + " km");
            System.out.println("route:");

            for (int j = connectedList.size() - 1; j >= 0; j--) {
                System.out.println(connectedList.get(j).parent + " to " + connectedList.get(j).current + ", " + (float) connectedList.get(j).cost + " km");
            }
        }
    }
}
